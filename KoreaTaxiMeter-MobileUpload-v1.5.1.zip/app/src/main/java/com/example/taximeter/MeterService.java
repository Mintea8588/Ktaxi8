package com.example.taximeter;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.*;
import androidx.annotation.NonNull;
import com.google.android.gms.location.*;
import java.util.*;

public class MeterService extends Service {
    private FusedLocationProviderClient client;
    private Location last;
    private long gapStart=0, lastTick=0;
    private double total=0, gapDistance=0;
    private float lastSpeed=0;
    private long lowSeconds=0;
    private static final double MIN_GAP=10.0, MAX_GAP_SEC=180.0, MAX_GAP_DISTANCE=5000.0;

    private final LocationCallback cb=new LocationCallback(){
        @Override public void onLocationResult(@NonNull LocationResult r){
            for(Location l:r.getLocations()) handle(l);
        }
    };

    @Override public void onCreate(){
        super.onCreate();
        client=LocationServices.getFusedLocationProviderClient(this);
        try { startForeground(77,notification("GPS 위치를 기다리는 중")); }
        catch(Exception e){ sendError("포그라운드 서비스 시작 실패"); stopSelf(); return; }
        request();
    }

    private void request(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            sendError("위치 권한이 없습니다"); stopSelf(); return;
        }
        LocationRequest req=new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,1000)
                .setMinUpdateIntervalMillis(500).setMaxUpdateDelayMillis(2000).build();
        try{
            client.requestLocationUpdates(req,cb,Looper.getMainLooper());
            client.getLastLocation().addOnSuccessListener(l->{ if(l!=null && last==null) handle(l); });
        }catch(SecurityException e){ sendError("위치 권한이 차단되어 있습니다"); stopSelf(); }
    }

    private void handle(Location l){
        if(l==null) return;
        long now=System.currentTimeMillis();
        TariffConfig c=new TariffConfig(this);
        float acc=l.hasAccuracy()?l.getAccuracy():999f;

        if(last==null){
            last=l; lastTick=now;
            send(l,c); return;
        }
        double dt=Math.max(0,(now-lastTick)/1000.0);

        if(acc>80f){
            if(gapStart==0) gapStart=lastTick;
            send(l,c); return;
        }

        if(gapStart>0){
            double gapSec=Math.max(0,(now-gapStart)/1000.0);
            float straight=last.distanceTo(l);
            double expected=Math.max(0,lastSpeed)*gapSec;
            boolean accepted=gapSec<=MAX_GAP_SEC && straight>=MIN_GAP && straight<=MAX_GAP_DISTANCE;
            if(accepted){
                double ratio=expected>1?straight/expected:1;
                accepted=expected<1 || (ratio>=0.35 && ratio<=2.8);
            }
            if(accepted){ total+=straight; gapDistance+=straight; }
            if(gapSec>0 && gapSec<=MAX_GAP_SEC && lastSpeed*3.6<c.lowSpeedKmh()) lowSeconds+=Math.max(0,Math.round(gapSec));
            gapStart=0;
        }else{
            float d=last.distanceTo(l);
            if(d>=MIN_GAP && d<1000 && dt<15) total+=d;
            if(lastSpeed*3.6<c.lowSpeedKmh() && dt>0 && dt<=5) lowSeconds+=Math.max(0,Math.round(dt));
        }

        if(l.hasSpeed()) lastSpeed=Math.max(0,l.getSpeed());
        else if(dt>0 && dt<=15) lastSpeed=Math.max(0,(float)(last.distanceTo(l)/dt));
        last=l; lastTick=now; send(l,c);
    }

    private int roundTo(int value,int unit){ return unit<=1?value:Math.round(value/(float)unit)*unit; }

    private int nightPercent(TariffConfig c){
        if(!c.autoNight()) return 0;
        Calendar now=Calendar.getInstance();
        int mins=now.get(Calendar.HOUR_OF_DAY)*60+now.get(Calendar.MINUTE);
        if(mins>=1380 || mins<120) return c.nightPeakPct(); // 23:00-02:00
        if(mins>=1320 || mins<240) return c.nightPct();    // 22:00-23:00, 02:00-04:00
        return 0;
    }

    private int[] appliedRates(TariffConfig c){
        int np=nightPercent(c), base=c.baseFare(), df=c.distanceUnitFare(), tf=c.timeUnitFare();
        if(np>0){
            base=roundTo(Math.round(base*(1+np/100f)),100);
            df=roundTo(Math.round(df*(1+np/100f)),10);
            tf=roundTo(Math.round(tf*(1+np/100f)),10);
        }
        return new int[]{base,df,tf,np};
    }

    private int calcFare(TariffConfig c){
        int[] r=appliedRates(c); int base=r[0],df=r[1],tf=r[2],np=r[3];
        double beyond=Math.max(0,total-c.baseDistanceM());
        int fare=base+(int)Math.floor(beyond/c.distanceUnitM())*df+(int)Math.floor(lowSeconds/(double)c.timeUnitSec())*tf;
        if(c.outOfArea()){
            int extra=Math.min(c.outPct(),Math.max(0,60-np));
            fare=Math.round(fare*(1+extra/100f));
        }
        return roundTo(fare,10);
    }

    private void send(Location l,TariffConfig c){
        int[] rates=appliedRates(c);
        Intent i=new Intent("METER_UPDATE");
        i.setPackage(getPackageName());
        i.putExtra("fare",calcFare(c));
        i.putExtra("distance",total/1000.0);
        i.putExtra("speed",lastSpeed*3.6);
        i.putExtra("gap",gapDistance/1000.0);

        double beyond=Math.max(0,total-c.baseDistanceM());
        boolean basePhase=total<c.baseDistanceM();
        int dMax=basePhase?Math.max(1,c.baseDistanceM()):Math.max(1,c.distanceUnitM());
        int dProgress;
        if(basePhase) dProgress=(int)Math.min(c.baseDistanceM(),Math.floor(total));
        else dProgress=(int)Math.floor(beyond%c.distanceUnitM());
        int dRemain=Math.max(0,dMax-dProgress);
        if(dRemain==0) dRemain=dMax;
        i.putExtra("basePhase",basePhase); i.putExtra("distanceRemain",dRemain); i.putExtra("distanceMax",dMax); i.putExtra("distanceProgress",dMax-dRemain);

        boolean timeActive=lastSpeed*3.6<c.lowSpeedKmh();
        int tMax=Math.max(1,c.timeUnitSec());
        int tProgress=(int)Math.floor(lowSeconds%tMax);
        int tRemain=Math.max(0,tMax-tProgress); if(tRemain==0)tRemain=tMax;
        i.putExtra("timeActive",timeActive); i.putExtra("timeRemain",tRemain); i.putExtra("timeMax",tMax); i.putExtra("timeProgress",tMax-tRemain);

        String status=l.hasAccuracy()&&l.getAccuracy()<=80?"GPS 정상":"GPS 신호 불량 · 보정 대기";
        i.putExtra("gps",status+" · ±"+(int)(l.hasAccuracy()?l.getAccuracy():0)+" m");
        String mode=timeActive?"● 시간·거리 동시병산 중":"● 거리 병산 중";
        if(gapStart>0) mode="● GPS 신호 보정 대기";
        i.putExtra("mode",mode);
        String night=rates[3]>0?" · 심야 "+rates[3]+"%":"";
        String out=c.outOfArea()?" · 시계외 "+c.outPct()+"%":"";
        i.putExtra("tariffSummary",String.format(Locale.KOREA,
                "현재 적용 · 기본 %,d원 / %,d m  ·  거리 %,d원 / %,d m  ·  시간 %,d원 / %d초%s%s",
                rates[0],c.baseDistanceM(),rates[1],c.distanceUnitM(),rates[2],c.timeUnitSec(),night,out));
        sendBroadcast(i);
    }

    private void sendError(String msg){
        Intent i=new Intent("METER_ERROR"); i.setPackage(getPackageName()); i.putExtra("message",msg); sendBroadcast(i); }

    private Notification notification(String s){
        String ch="meter"; NotificationManager nm=getSystemService(NotificationManager.class);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(ch,"Taxi Meter",NotificationManager.IMPORTANCE_LOW));
        return new Notification.Builder(this,ch).setContentTitle("Korea Taxi Meter").setContentText(s).setSmallIcon(android.R.drawable.ic_menu_mylocation).build();
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){ return START_NOT_STICKY; }
    @Override public void onDestroy(){ if(client!=null) client.removeLocationUpdates(cb); super.onDestroy(); }
    @Override public IBinder onBind(Intent i){return null;}
}
